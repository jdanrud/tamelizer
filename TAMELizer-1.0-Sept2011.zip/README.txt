
============== Release Notes for TAMELizer V1.0, September 2011 =============

=========== Overview:

- The TAMELizer test tool is made available to you under the LGPL License.
See joint license, by Fujitsu America, Inc. 
This open source license allows for commercial reuse and embedding.

- the TAMELizer test tool is developped initially and maintained by Fujitsu company.
It is currently hosted in Google Code as an Open Source project: 
(http://code.google.com/p/tamelizer/)

- the TAMELizer download package contains all the code (XSLT 2.0 scripts) that define
the test tool. There is no other code left out of the package.

- This version (1.0) of the TAMELizer test tool is an incremental release over V0.96.
However its major motivation is to align with the finalized test assertions markup TAML 
(as published by OASIS TAG: http://www.oasis-open.org/committees/tc_home.php?wg_abbrev=tag ).
 

=========== Out of the box:

- The TAMELizer test tool package contains a set of sample files (related to particular 
sets of test assertions used as samples) that are are zipped separately (in Examples-Files.zip). 
After you un-zip the TAMELizer package, the simplest way forward is to 
un-zip the set of example files at the same directory level so you can run the sample files.

- A good way to start is to browse the sample report "testreport-NIEM-TAMLXschema.html"
which shows the result of applying some test assertions from NIEM (see "Getting Started"
in the User Guide) to the XML schema included in this package.

- See the User Guide (TAMELizer-UserGuide.pdf) for more information about every file in this package, 
and the reference specification for TAML-X (TAML-X-Reference-rev10.pdf).

- NOTE: In order to avoid some security filtering of some mail servers, the batch file 
script sample "xslt.bat" for Windows has been renamed: "xslt.txt".
After unzipping, if using a Windows environment just rename it xslt.bat. 
Modify its content - or the content of the Unix counterpart script "xslt.sh" 
to match your installation of an XSLT2.0 processor. These "xslt" script files
assume you have installed an XSLT 2.0 processor (see User Guide).

- Once you have an XSLT2.0 engine deployed (see User guide) you'll have to 
execute a two-step sequence. 
In a nutshell (here using the sample test assertions file 'widgetTAs.xml'): 

(1) analyzer code generation:
>xslt genanalyzer.xsl widgetTAs.xml testanalyzer.xsl

(2) test execution:
>xslt testdriver.xsl widgetDesignLog.xml testreport.xml

See the User Guide for more explanations.


=========== Changes from previous release 0.96:

1- Alignment with TAML specification from OASIS TAG:

The prime reason for this release, is the alignment with the now stable TAML schema 
(see: testAssertionMarkupLanguage.xsd), which is now the schema of reference for TAML-X test assertions. 
- Will your V0.96 TAs validate against this schema? Possibly not if they are using these features:
variables and the @enable attribute. Indeed, var/@name has been renamed var/@vname, and
testAssertion/@enable has been renamed: testAssertion/@tamlx:enable as it is an extension to 
TAML schema and all extensions must be under a new namespace (here TAML-X namespace).
(backward compatible, except for testAssertion/@tamlx:enable )
- But what changes do I need to do to run my V0.96 TAs with tamelizer 1.0 ?
(since tamelizer does not really need schema validation)
You need to rename testAssertion/@enable as testAssertion/@tamlx:enable (and declare tamlx namespace)
otherwise this attribute value will be ignored, which means a disabled TA (enable="false") 
will actually execute.
You should rename var/@name --> var/@vname although V1.0 is accepting var/@name as just deprecated.


2- Bugs fixed:

- predicate  or prerequisite expressions containing TA refs of the abbreviated form (no parenthesis after TA name)
e.g. taml:TA123 eq 'pass' instead of taml:TA123() eq 'pass' 
were not parsed properly when using value-comparison operators like 'eq' and 'ne' instead of '=' and '!='.

- disabling some test assertions (enable="false") did not have the same effect as just commenting them out:
more of them were ignored due to a bad "precedence" target/@type XPath test, depending on their position.


3- Other improvements:

- The HTML rendering (report.xsl) of the generated report has been improved:
o simplified the "general information" header part of the report.
o better formatting of the "Summary Test Results" part.
o when there is no targets for an TA test outcome (e.g. pass/fail/etc.), or no TA for a target test outcome, 
report says "(none)" instead of nothing.

- User guide and also TAML-X reference specification have been updated, to reflect
the above changes.


===== BACKWARD COMPATIBILITY (with 0.96):

(we'll try to minimize breaking compatibility as much as possible... and certainly avoid them from v1.0 on)

For V1.0, Test Assertions markup has changed as follows from what V0.96 was processing:
- testAssertion/@enable is now: testAssertion/@tamlx:enable 
- testAssertion/var/@name is now: testAssertion/var/@vname (although @name is still accepted).
So if you do not do these upgrades on your old set of TAs, it should still run as is, except for 
disabled TAs (@enable="false") which will execute by default since @enable no longer recognized.


=========== Known limitations: (to be removed in a future release)

- In the current release, TAs with ill-written XPath expressions may cause 
the test engine to simply crash, as there is no exception catching mechanism in XSLT 2.0. 
(but there will be in XSLT 2.1 and beyond).
E.g. some XPath function in your test assertion is using an XPath expression 
that returns a sequence of nodes. Using such an expression as argument of a function 
that expects a single node, will crash the run-time analyzer.
An error-detection preprocessor will alleviate this in a subsequent release.


=========== Legal:

- The TAMELizer engine code is made available to you on the 
Lesser General Public License (LGPL).
This open source license allows for inclusion in commercial products.
See joint license. Initial contributor is Fujitsu America, Inc. 

=========== Feedback:

Please use the google group "tamel-users" (http://groups.google.com/group/tamel-users)
In case of difficulty, notify: jdurand@us.fujitsu.com, with email title including:
 (case insensitive) "tamelizer".

