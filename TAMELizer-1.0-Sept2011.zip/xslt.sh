#!/bin/sh

java -classpath $SAXON_HOME/saxon9-ant.jar:$SAXON_HOME/saxon9-dom.jar:$SAXON_HOME/saxon9-dom4j.jar:$SAXON_HOME/saxon9-jdom.jar:$SAXON_HOME/saxon9-s9api.jar:$SAXON_HOME/saxon9-sql.jar:$SAXON_HOME/saxon9-xom.jar:$SAXON_HOME/saxon9-xpath.jar:$SAXON_HOME/saxon9-xqj.jar:$SAXON_HOME/saxon9.jar -jar $SAXON_HOME/saxon9.jar -s $2 -o $3   $1
